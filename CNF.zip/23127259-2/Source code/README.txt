Các bước để có thể chạy chương trình:
+ Bước 1: Giải nén file zip 23127259.zip
+ Bước 2: Mở visual studio code
+ Bước 3: Chọn File và sau đó chọn Open Folder và chọn Folder 23127259 đã được giải nén
+ Bước 4: Chọn Folder Source code và chọn open
+ Bước 5: Mở terminal để chạy và kiểm tra python và pip đã được tải chưa. Sau đó cài thư viện pysat bằng lệnh: pip install python-sat
+ Bước 6: Sau khi cài xong chạy tiếp lệnh: python main.py để chạy chương trình và ghi ra kết quả